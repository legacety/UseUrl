local acr = require("arz-core")

local libs = {
    {name = "#another.lua", url = "https://raw.githubusercontent.com/wojciech941/arizona-events/refs/heads/main/arizona-events/subprocess.lua"},
}

function main()
    if not isSampLoaded() or not isSampfuncsLoaded() then return end
    while not isSampAvailable() do wait(100) end
    acr(libs) 
    wait(-1)
end